package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils.WaitUtils;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

public class ProductPage {

    private final WebDriver driver;
    private final WaitUtils wait;
    private final WebDriverWait wait8;

    public ProductPage(WebDriver driver){
        this.driver = driver;
        this.wait = new WaitUtils(driver);
        this.wait8 = new WebDriverWait(driver, Duration.ofSeconds(8));
    }

    // PDP title confirms page loaded
    private final By pdpTitle = By.cssSelector("h1");

    // Related section header
    private final By relatedHeader =
            By.xpath("//*[contains(text(),'You may also like') or contains(text(),'Related')]");

    // Product cards inside related section
    private final By relatedCards =
            By.xpath("//*[contains(text(),'You may also like')]/following::div[contains(@class,'product')][1]/ancestor::section//div[contains(@class,'product')]");

    // -------------------------------------------------
    // 1️⃣ Wait for PDP
    // -------------------------------------------------
    public void waitUntilLoaded(){
        wait8.until(ExpectedConditions.visibilityOfElementLocated(pdpTitle));
    }

    // -------------------------------------------------
    // 2️⃣ Scroll to Related Section
    // -------------------------------------------------
    public void scrollToRelatedSection(){

        waitUntilLoaded();

        ((JavascriptExecutor) driver)
                .executeScript("window.scrollTo(0, document.body.scrollHeight * 0.85);");

        try{
            wait8.until(ExpectedConditions.visibilityOfElementLocated(relatedHeader));
        }catch(Exception ignored){}
    }

    // -------------------------------------------------
    // 3️⃣ Capture Top N Products (NAME + PRICE FIXED)
    // --------------
    public List<String[]> captureYouMayAlsoLikeTopN(int n){

        List<String[]> results = new ArrayList<>();

        // Wait for section
        wait8.until(ExpectedConditions.visibilityOfElementLocated(
                By.id("you-may-also-like")
        ));

        // Get all product slides inside section
        List<WebElement> cards = driver.findElements(
                By.xpath("//div[@id='you-may-also-like']//div[@data-index]")
        );

        for(WebElement card : cards){

            if(results.size() >= n) break;

            try{

                // PRODUCT NAME (stable using aria-label)
                WebElement nameElement = card.findElement(
                        By.xpath(".//a[@aria-label]")
                );

                String name = nameElement.getAttribute("aria-label").trim();

                // PRODUCT PRICE (first price only)
                List<WebElement> priceParts = card.findElements(
                        By.xpath(".//div[text()='₹']/following-sibling::div[1]")
                );

                String price = "";

                if(!priceParts.isEmpty()){
                    price = "₹ " + priceParts.get(0).getText().trim();
                }

                if(!name.isBlank()){
                    results.add(new String[]{name, price});
                }

            }catch(Exception ignored){}
        }

        return results;
    }

    // -------------------------------------------------
    // 4️⃣ Open First Product
    // -------------------------------------------------
    public void openFirstProduct(){

        By firstProduct =
                By.cssSelector("a[href*='/p/'], a[href*='/product/']");

        WebElement link = wait8.until(
                ExpectedConditions.elementToBeClickable(firstProduct)
        );

        driver.navigate().to(link.getAttribute("href"));

        waitUntilLoaded();
    }
}
